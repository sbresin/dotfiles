using System;

namespace ARMeilleure.Translation
{
    delegate ulong GuestFunction(IntPtr nativeContextPtr);
}
