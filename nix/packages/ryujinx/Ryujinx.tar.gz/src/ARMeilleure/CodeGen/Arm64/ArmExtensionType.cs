namespace ARMeilleure.CodeGen.Arm64
{
    enum ArmExtensionType
    {
        Uxtb = 0,
        Uxth = 1,
        Uxtw = 2,
        Uxtx = 3,
        Sxtb = 4,
        Sxth = 5,
        Sxtw = 6,
        Sxtx = 7,
    }
}
