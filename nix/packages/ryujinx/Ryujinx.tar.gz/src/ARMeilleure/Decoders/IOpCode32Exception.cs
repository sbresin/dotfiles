namespace ARMeilleure.Decoders
{
    interface IOpCode32Exception
    {
        int Id { get; }
    }
}
