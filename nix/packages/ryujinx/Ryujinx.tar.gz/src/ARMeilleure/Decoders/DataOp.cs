namespace ARMeilleure.Decoders
{
    enum DataOp
    {
        Adr = 0,
        Arithmetic = 1,
        Logical = 2,
        BitField = 3,
    }
}
