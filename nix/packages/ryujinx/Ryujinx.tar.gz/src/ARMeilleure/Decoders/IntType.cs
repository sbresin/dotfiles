namespace ARMeilleure.Decoders
{
    enum IntType
    {
        UInt8 = 0,
        UInt16 = 1,
        UInt32 = 2,
        UInt64 = 3,
        Int8 = 4,
        Int16 = 5,
        Int32 = 6,
        Int64 = 7,
    }
}
